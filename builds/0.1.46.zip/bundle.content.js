/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/content_scripts/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/content_scripts/index.js":
/*!**************************************!*\
  !*** ./src/content_scripts/index.js ***!
  \**************************************/
/*! exports provided: config, updateConfig */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"config\", function() { return config; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"updateConfig\", function() { return updateConfig; });\n/* harmony import */ var _reddit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reddit */ \"./src/content_scripts/reddit/index.js\");\n/* harmony import */ var _lib_fields__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lib/fields */ \"./src/content_scripts/lib/fields.js\");\n/* harmony import */ var _listeners__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./listeners */ \"./src/content_scripts/listeners.js\");\n\n\n\n\n// instantiate all listeners\n\n\nlet config = {};\n\nfunction updateConfig(newConfig) {\n  config = newConfig;\n}\n\n// send message to background.js to show page action\nchrome.runtime.sendMessage({\n  from: 'content',\n  subject: 'ShowPageAction'\n});\n\n// load user configuration\nchrome.storage.sync.get(_lib_fields__WEBPACK_IMPORTED_MODULE_1__[\"default\"].map(field => field.id), storage => {\n  const defaults = _lib_fields__WEBPACK_IMPORTED_MODULE_1__[\"default\"].reduce((acc, val, index) => index === 1\n    ? Object.assign({ [acc.id]: acc.defaultValue }, { [val.id]: val.defaultValue })\n    : Object.assign(acc, { [val.id]: val.defaultValue })\n  );\n\n  config = {\n    ...defaults,\n    ...storage,\n  };\n\n  // chrome.runtime.sendMessage({\n  //   from: 'content',\n  //   subject: 'UserConfigLoaded',\n  //   data: config,\n  // });\n  console.log('initialized with config: ', config);\n});\n\n// initialize polling to remove elements\n(function poll() {\n  Object(_reddit__WEBPACK_IMPORTED_MODULE_0__[\"removeElements\"])(config);\n  setTimeout(poll, 1000);\n})();\n\n\n//# sourceURL=webpack:///./src/content_scripts/index.js?");

/***/ }),

/***/ "./src/content_scripts/lib/fields.js":
/*!*******************************************!*\
  !*** ./src/content_scripts/lib/fields.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\nconst fields = [\n  {\n    id: 'voteButtons',\n    label: 'Vote buttons',\n    defaultValue: true,\n  },\n  {\n    id: 'postScore',\n    label: 'Post score',\n    defaultValue: true,\n  },\n  {\n    id: 'commentScore',\n    label: 'Comment score',\n    defaultValue: true,\n  },\n  {\n    id: 'karma',\n    label: 'Karma',\n    defaultValue: true,\n  },\n  {\n    id: 'commentCount',\n    label: 'Comment count',\n    defaultValue: false,\n  },\n  {\n    id: 'gildBadge',\n    label: 'Gild badge',\n    defaultValue: false,\n  },\n];\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (fields);\n\n\n//# sourceURL=webpack:///./src/content_scripts/lib/fields.js?");

/***/ }),

/***/ "./src/content_scripts/listeners.js":
/*!******************************************!*\
  !*** ./src/content_scripts/listeners.js ***!
  \******************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _reddit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reddit */ \"./src/content_scripts/reddit/index.js\");\n/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index */ \"./src/content_scripts/index.js\");\n\n\n\n// enhance performance for back/forward button\nwindow.addEventListener('popstate', _reddit__WEBPACK_IMPORTED_MODULE_0__[\"removeElements\"]);\n\n// Listen for messages from the popup\nchrome.runtime.onMessage.addListener(function (msg, sender, response) {\n  const { from, subject, data } = msg;\n\n  if (from === 'popup') {\n    switch (subject) {\n      case 'UpdateConfig': {\n        Object(_index__WEBPACK_IMPORTED_MODULE_1__[\"updateConfig\"])(data);\n        break;\n      }\n\n      default:\n        return false;\n    }\n  }\n});\n\n\n//# sourceURL=webpack:///./src/content_scripts/listeners.js?");

/***/ }),

/***/ "./src/content_scripts/reddit/functions/commentCount.js":
/*!**************************************************************!*\
  !*** ./src/content_scripts/reddit/functions/commentCount.js ***!
  \**************************************************************/
/*! exports provided: removeCommentCount */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"removeCommentCount\", function() { return removeCommentCount; });\nconst removeCommentCount = () => {\n  const { noDisplay } = __webpack_require__(/*! ../index.js */ \"./src/content_scripts/reddit/index.js\");\n  // ---------------------------------------------------------------------------\n  // old\n  // ---------------------------------------------------------------------------\n\n  // list page\n  try {\n    const commentCountElems = document.querySelectorAll('.bylink.comments');\n    commentCountElems && Array.prototype.forEach.call(commentCountElems, e => {\n      const regex = new RegExp(/[0-9]/g);\n      const test = regex.test(e.innerHTML);\n      if (!!test) {\n        e.innerHTML = 'Comments';\n      }\n    });\n  } catch (e) {\n    // assume not on list page\n  }\n\n  // post detail page\n  try {\n    const commentCountElems = document.querySelector('.commentarea .panestack-title .title');\n    commentCountElems.style = noDisplay;\n  } catch (e) {\n    // assume not on post detail page\n  }\n\n  // ---------------------------------------------------------------------------\n  // new\n  // ---------------------------------------------------------------------------\n\n  // list page\n  try {\n    const commentCountElems = document.querySelectorAll('a[data-click-id=\"comments\"]');\n    const regex = new RegExp(/[0-9]/g);\n    commentCountElems && Array.prototype.forEach.call(commentCountElems, e => {\n      const test = regex.test(e.innerHTML);\n      if (!!test) {\n        e.innerHTML = 'Comments';\n      }\n    });\n  } catch (e) {\n    // assume not on list page\n  }\n\n  // post detail page\n  try {\n    const commentCountElems = document.querySelectorAll('i.icon.icon-comment');\n    const regex = new RegExp(/[0-9.]+[ k]+comments?/gi);\n    commentCountElems && Array.prototype.forEach.call(commentCountElems, e => {\n      const ele = e.nextSibling;\n      const test = regex.test(ele.innerHTML);\n      if (!!test) {\n        ele.innerHTML = 'Comments';\n      }\n\n      // do % upvoted while we're here, this gets crazy\n      const commentWrapper = e.parentNode;\n      const menuWrapper = commentWrapper.parentNode;\n      const actionBar = menuWrapper.parentNode;\n      const upvoted = document.querySelector(`.${actionBar.className} > div:nth-child(2)`);\n      upvoted.style = noDisplay;\n    });\n  } catch (e) {\n    // assume not on post detail page\n  }\n}\n\n\n//# sourceURL=webpack:///./src/content_scripts/reddit/functions/commentCount.js?");

/***/ }),

/***/ "./src/content_scripts/reddit/functions/commentScore.js":
/*!**************************************************************!*\
  !*** ./src/content_scripts/reddit/functions/commentScore.js ***!
  \**************************************************************/
/*! exports provided: removeCommentScore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"removeCommentScore\", function() { return removeCommentScore; });\n// import { noDisplay } from '../index.js';\n// console.log('noDisplay: ', noDisplay);\n// redesign uses randomized, hashed class names. this function is an attempt to\n// best guess the one used to display comment scores\nfunction getCommentScoreClass(ctx, done) {\n  let error, classes;\n\n  try {\n    // scores are currently rendered as two spans: '<span>X point[s]</span><span> · </span>'\n    // points are somtimes replaced by 'score hidden'\n    const scoreEx = new RegExp(/(\\d+.*\\spoint[s]?)|(score)/i);\n    const dotEx = new RegExp(/\\s·\\s/);\n\n    if (\n      scoreEx.test(ctx.innerHTML) &&\n      dotEx.test(ctx.nextSibling.innerHTML)\n    ) {\n      classes = ctx.className.split(' ').map(c => `.${c}`).join('');\n    }\n  } catch (e) {\n    error = e || true;\n  }\n\n  return done(error, classes);\n}\n\nfunction removeCommentScore() {\n  const { noDisplay } = __webpack_require__(/*! ../index.js */ \"./src/content_scripts/reddit/index.js\");\n  // ---------------------------------------------------------------------------\n  // old\n  // ---------------------------------------------------------------------------\n\n  // catch-all\n  const scores = document.querySelectorAll('div.score, span.score');\n  Array.prototype.forEach.call(scores, e => {\n    e.style = noDisplay;\n  });\n\n  // user profile page\n  try {\n    const usernames = document.querySelectorAll('a.Post__username');\n    Array.prototype.forEach.call(usernames, e => {\n      const parentNode = e.parentNode;\n\n      if (e.innerHTML.substr(e.length - 1) !== ' ') {\n        e.innerHTML += ' ';\n      }\n\n      Array.prototype.forEach.call(parentNode.childNodes, n => {\n        if (n.nodeType === 3) {\n          parentNode.removeChild(n);\n        }\n      })\n    });\n  } catch (e) {\n    // assume not on user profile page\n  }\n\n  // ---------------------------------------------------------------------------\n  // new\n  // ---------------------------------------------------------------------------\n\n  // get one comment element to find comment points class name for redesign\n  // user comments are currently kept in <p> tags and will be excluded\n  const commentSpan = document.querySelector('div.Comment span:nth-child(2)');\n  commentSpan && getCommentScoreClass(commentSpan, (err, res) => {\n    if (!err && res) {\n      const points = document.querySelectorAll(res);\n\n      Array.prototype.forEach.call(points, e => {\n        e.style = noDisplay;\n      });\n    }\n  });\n}\n\n\n//# sourceURL=webpack:///./src/content_scripts/reddit/functions/commentScore.js?");

/***/ }),

/***/ "./src/content_scripts/reddit/functions/gildBadge.js":
/*!***********************************************************!*\
  !*** ./src/content_scripts/reddit/functions/gildBadge.js ***!
  \***********************************************************/
/*! exports provided: removeGildBadge */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"removeGildBadge\", function() { return removeGildBadge; });\nconst removeGildBadge = () => {\n  const { noDisplay } = __webpack_require__(/*! ../index.js */ \"./src/content_scripts/reddit/index.js\");\n  // ---------------------------------------------------------------------------\n  // gilded identifiers (old reddit)\n  // ---------------------------------------------------------------------------\n  try {\n    const gildedIcons = document.querySelectorAll('.gilded-gid1-icon, .gilded-gid2-icon, .gilded-gid3-icon');\n    gildedIcons && Array.prototype.forEach.call(gildedIcons, e => {\n      e.style = noDisplay;\n    });\n  } catch (e) {\n    // assume not on list page\n  }\n\n  // ---------------------------------------------------------------------------\n  // gilded identifiers (redesign)\n  // ---------------------------------------------------------------------------\n  try {\n    const gildedIcons = document.querySelectorAll('i[id*=\"PostAwardBadges\"], i[id*=\"CommentAwardBadges\"]');\n    gildedIcons && Array.prototype.forEach.call(gildedIcons, e => {\n      e.style = noDisplay;\n    });\n  } catch (e) {\n    // assume not on list page\n  }\n};\n\n\n//# sourceURL=webpack:///./src/content_scripts/reddit/functions/gildBadge.js?");

/***/ }),

/***/ "./src/content_scripts/reddit/functions/index.js":
/*!*******************************************************!*\
  !*** ./src/content_scripts/reddit/functions/index.js ***!
  \*******************************************************/
/*! exports provided: removeCommentCount, removeCommentScore, removeGildBadge, removeKarma, removePostScore, removeVoteButtons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _commentCount__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./commentCount */ \"./src/content_scripts/reddit/functions/commentCount.js\");\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"removeCommentCount\", function() { return _commentCount__WEBPACK_IMPORTED_MODULE_0__[\"removeCommentCount\"]; });\n\n/* harmony import */ var _commentScore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commentScore */ \"./src/content_scripts/reddit/functions/commentScore.js\");\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"removeCommentScore\", function() { return _commentScore__WEBPACK_IMPORTED_MODULE_1__[\"removeCommentScore\"]; });\n\n/* harmony import */ var _gildBadge__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./gildBadge */ \"./src/content_scripts/reddit/functions/gildBadge.js\");\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"removeGildBadge\", function() { return _gildBadge__WEBPACK_IMPORTED_MODULE_2__[\"removeGildBadge\"]; });\n\n/* harmony import */ var _karma__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./karma */ \"./src/content_scripts/reddit/functions/karma.js\");\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"removeKarma\", function() { return _karma__WEBPACK_IMPORTED_MODULE_3__[\"removeKarma\"]; });\n\n/* harmony import */ var _postScore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./postScore */ \"./src/content_scripts/reddit/functions/postScore.js\");\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"removePostScore\", function() { return _postScore__WEBPACK_IMPORTED_MODULE_4__[\"removePostScore\"]; });\n\n/* harmony import */ var _voteButtons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./voteButtons */ \"./src/content_scripts/reddit/functions/voteButtons.js\");\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"removeVoteButtons\", function() { return _voteButtons__WEBPACK_IMPORTED_MODULE_5__[\"removeVoteButtons\"]; });\n\n\n\n\n\n\n\n\n\n//# sourceURL=webpack:///./src/content_scripts/reddit/functions/index.js?");

/***/ }),

/***/ "./src/content_scripts/reddit/functions/karma.js":
/*!*******************************************************!*\
  !*** ./src/content_scripts/reddit/functions/karma.js ***!
  \*******************************************************/
/*! exports provided: removeKarma */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"removeKarma\", function() { return removeKarma; });\nconst removeKarma = () => {\n  const { noDisplay } = __webpack_require__(/*! ../index.js */ \"./src/content_scripts/reddit/index.js\");\n  // ---------------------------------------------------------------------------\n  // old\n  // ---------------------------------------------------------------------------\n\n  // catch-all\n  const karmaSpans = document.querySelectorAll('span[class*=\"karmaSpans\"]');\n  Array.prototype.forEach.call(karmaSpans, e => {\n    e.style = noDisplay;\n  });\n\n  // ---------------------------------------------------------------------------\n  // new\n  // ---------------------------------------------------------------------------\n\n  // header if logged in\n  try {\n    const currentUserInfo = document.querySelector('.header-user-dropdown img').nextSibling;\n    const currentUserKarma = currentUserInfo.querySelector('span');\n    currentUserKarma.style = noDisplay;\n  } catch (e) {\n    // assume not logged in\n  }\n\n  // user profile page if displayed\n  try {\n    const userProfileKarma = document.querySelector('span#profile--id-card--highlight-tooltip--karma').parentNode.parentNode;\n    userProfileKarma.style = noDisplay;\n\n    if (userProfileKarma && userProfileKarma.previousSibling) {\n      userProfileKarma.previousSibling.style = noDisplay;\n    }\n  } catch (e) {\n    // assume not on user profile page\n  }\n\n  // hovering a user's name\n  try {\n    const tooltipDivs = document.querySelectorAll('div[id*=\"UserInfoTooltip\"] div > div > div');\n    Array.prototype.forEach.call(tooltipDivs, e => {\n      if (e.innerHTML.toLowerCase().indexOf('karma') >= 0) {\n        e.parentNode.style = noDisplay;\n      }\n    });\n  } catch (e) {\n    // assume not hovering a user's name\n  }\n};\n\n\n//# sourceURL=webpack:///./src/content_scripts/reddit/functions/karma.js?");

/***/ }),

/***/ "./src/content_scripts/reddit/functions/postScore.js":
/*!***********************************************************!*\
  !*** ./src/content_scripts/reddit/functions/postScore.js ***!
  \***********************************************************/
/*! exports provided: removePostScore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"removePostScore\", function() { return removePostScore; });\nconst removePostScore = () => {\n  const { noDisplay } = __webpack_require__(/*! ../index.js */ \"./src/content_scripts/reddit/index.js\");\n\n};\n\n\n//# sourceURL=webpack:///./src/content_scripts/reddit/functions/postScore.js?");

/***/ }),

/***/ "./src/content_scripts/reddit/functions/voteButtons.js":
/*!*************************************************************!*\
  !*** ./src/content_scripts/reddit/functions/voteButtons.js ***!
  \*************************************************************/
/*! exports provided: removeVoteButtons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"removeVoteButtons\", function() { return removeVoteButtons; });\nconst removeVoteButtons = () => {\n  const { noDisplay } = __webpack_require__(/*! ../index.js */ \"./src/content_scripts/reddit/index.js\");\n  // TODO: add option to allow comment votes\n  // const buttons = document.querySelectorAll('div:not(.Comment) > div > [aria-label=\"upvote\"]');\n\n  // ---------------------------------------------------------------------------\n  // both\n  // ---------------------------------------------------------------------------\n\n  // post list and post details\n  let buttons = document.querySelectorAll('[aria-label=\"upvote\"]');\n  Array.prototype.forEach.call(buttons, e => {\n    e.parentNode.innerHTML = '&nbsp;';\n  });\n\n  // user profile page if displayed\n  try {\n    buttons = document.querySelectorAll('span[class*=\"Post__scoreDisplay\"]');\n    Array.prototype.forEach.call(buttons, e => {\n      e.innerHTML = '&nbsp;';\n    });\n  } catch (e) {\n    // assume not on user profile page\n  }\n};\n\n\n//# sourceURL=webpack:///./src/content_scripts/reddit/functions/voteButtons.js?");

/***/ }),

/***/ "./src/content_scripts/reddit/index.js":
/*!*********************************************!*\
  !*** ./src/content_scripts/reddit/index.js ***!
  \*********************************************/
/*! exports provided: noDisplay, removeElements */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"noDisplay\", function() { return noDisplay; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"removeElements\", function() { return removeElements; });\n/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./functions */ \"./src/content_scripts/reddit/functions/index.js\");\n/* harmony import */ var _index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../index.js */ \"./src/content_scripts/index.js\");\n\n\n\n\nconst noDisplay = 'display: none';\n\nfunction removeElements(config = _index_js__WEBPACK_IMPORTED_MODULE_1__[\"config\"]) {\n  Object.keys(config).forEach(key => {\n    if (!!config[key]) {\n      const method = `remove${key.charAt(0).toUpperCase()}${key.slice(1)}`;\n      _functions__WEBPACK_IMPORTED_MODULE_0__[method]();\n    }\n  });\n}\n\n\n//# sourceURL=webpack:///./src/content_scripts/reddit/index.js?");

/***/ })

/******/ });